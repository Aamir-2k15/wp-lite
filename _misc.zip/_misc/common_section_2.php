<section id="common_section_2">
    <div class="container"> 
        <div class="row">
            <div class="d-flex flex-md-row flex-column">
                <?php is_active_sidebar('common_section_2') ? dynamic_sidebar('common_section_2') : ''; ?>
            </div>
        </div> 
    </div>
</section>