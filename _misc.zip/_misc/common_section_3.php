<section id="common_section_3">
    <div class="container"> 
        <div class="row">
            <div class="d-flex flex-md-row flex-column">
                <?php is_active_sidebar('common_section_3') ? dynamic_sidebar('common_section_3') : ''; ?>
            </div>
        </div> 
    </div>
</section>